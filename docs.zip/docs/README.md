# Static OOP Quiz Site


- Chạy dev: `npm i && npm run dev` (thêm script vào package.json: `vite`).
- Build: `npm run build` → xuất `dist/` (upload lên GitHub Pages/Netlify).
- Nội dung đề ở `content/quizzes/*.json`. Thêm đề mới → thêm route trong `src/ui/App.ts`.


> Giao diện giữ phong cách từ file HTML nguyên bản của bạn (Tailwind + card, button, score bar).
