# Giới thiệu
Ứng dụng ôn tập dựa trên nội dung tĩnh (JSON/Markdown), chấm điểm offline-first.
