// Placeholder cho đồng bộ local ↔ remote nếu cần sau này
export class SyncService { /* ... */ }
