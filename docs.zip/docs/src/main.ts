import './ui/components/NavTabs';
import { App } from './ui/App';


const mount = document.getElementById('app')!;
new App(mount).start();
